$("#btn_obj").on("click", function () {
        swal({
            title: "编辑成功",
            type: "success",
        })
});