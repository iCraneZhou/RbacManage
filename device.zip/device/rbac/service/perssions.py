###############################在session注册权限列表##############################
def initial_session(user,request):

    #获取当前用户所在的所有角色拥有的权限url，组id，动作，去掉重复
    permissions = user.roles.all().values("permissions__url","permissions__group_id","permissions__action").distinct()

    #把结果放到一个字典中
    permission_dict={}
    for item in permissions:
        gid=item.get('permissions__group_id')

        #判断当前组是否已经存在到字典中
        if not gid in permission_dict:

            #加逗号是因为考虑还有数据
            #permission_dict{1:{"url":["/device_list/"],"action":"[search"]},2:{"url":["/device_list/"],"action":["search"}]}
            permission_dict[gid]={
                "urls":[item["permissions__url"],],
                "actions":[item["permissions__action"],]
            }
        else:
            permission_dict[gid]["urls"].append(item["permissions__url"])
            permission_dict[gid]["actions"].append(item["permissions__action"])

    request.session['permission_dict'] = permission_dict

