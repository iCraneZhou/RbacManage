"""device URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from project01 import views



urlpatterns = [
    url('^$',views.index),
    url('^admin/', admin.site.urls),
    url('^index/',views.login),
    url('^logout/',views.logout),
    #设备url
    url('^device_list/',views.device_list),
    url('^add_device/',views.add_device),
    url('^del_device/(\d+)',views.del_device),
    url('^edit_device/(\d+)',views.edit_device),
    #用户url
    url('^user_list/',views.user_list),
    url('^add_user/',views.add_user),
    url('^del_user/(\d+)',views.del_user),
    url('^edit_user/(\d+)',views.edit_user),
    #采购url
    # url('^login/',views.login),
    url('^buy_list/',views.buy_list),
    url('^add_buy/',views.add_buy),
    url('^del_buy/(\d+)',views.del_buy),
    url('^edit_buy/(\d+)',views.edit_buy),
    #登记url
    url('cons_list/',views.cons_list),
    url('^add_cons/',views.add_cons),
    url('^del_cons/(\d+)',views.del_cons),
    url('^edit_cons/(\d+)',views.edit_cons),
    #配件url
    url('^access_list/',views.access_list),
    url('^add_access/',views.add_access),
    url('^del_access/(\d+)',views.del_access),
    url('^edit_access/(\d+)',views.edit_access),
    #资产清理url
    url('^scrap_list/',views.scrap_list),
    url('^add_scrap/',views.add_scrap),
    url('^del_scrap/(\d+)',views.del_scrap),
    url('^edit_scrap/(\d+)',views.edit_scrap),
    #配置统计url
    url('^stat_list/', views.stat_list),
    url('^add_stat/', views.add_stat),
    url('^del_stat/(\d+)', views.del_stat),
    url('^edit_stat/(\d+)', views.edit_stat),
]
