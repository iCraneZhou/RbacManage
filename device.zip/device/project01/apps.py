from django.apps import AppConfig


class Project01Config(AppConfig):
    name = 'project01'
