from django.db import models

# 设备表
class Device(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(u"名称",max_length=32,null=False)
    type = models.CharField(u'类型',max_length=64,null=False)
    model_number = models.CharField(u'型号',max_length=64)
    count = models.SmallIntegerField(u'数量')
    status = models.CharField(u'状态',max_length=10)
    register = models.DateField(u'日期')
    note = models.CharField(u'备注',max_length=64,null=True,blank=True)

#用户表
class User(models.Model):
    id   = models.AutoField(primary_key=True)
    name = models.CharField(u'姓名',max_length=20,null=False)
    type = models.ForeignKey(to="Device",on_delete=models.SET_NULL,null=True,related_name="types")
    model_number = models.ForeignKey(to="Device",on_delete=models.SET_NULL,null=True,related_name="model_numbers")
    count = models.SmallIntegerField(u'数量')
    start_time = models.DateField(u'日期')
    stop_time  = models.DateField(u'日期')
    note = models.CharField(u'备注',max_length=64,null=True,blank=True)


#申购表
class Buy(models.Model):
    id  = models.AutoField(primary_key=True)
    name = models.CharField(u'名称',max_length=32,null=False)
    unit = models.CharField(u'单位',max_length=8)
    count = models.SmallIntegerField(u'数量')
    price = models.DecimalField(u'价格', max_digits=9, decimal_places=2)
    reason = models.CharField(u'理由',max_length=128)
    date = models.DateField(u'日期')
    section = models.CharField(u'部门',max_length=16)
    user = models.CharField(u'姓名',max_length=16)
    note = models.CharField(u'备注',max_length=16,null=True,blank=True)

#耗材领用
class Consumable(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(u'名称',max_length=32,null=False)
    unit = models.CharField(u'单位',max_length=8)
    count = models.SmallIntegerField(u'数量')
    receive = models.CharField(u'领用人',max_length=12)
    section = models.CharField(u'部门', max_length=16)
    receive_date = models.DateTimeField(u'领用日期',auto_now_add=True)
    handle = models.CharField(u'登记人', max_length=12)
    note = models.CharField(u'备注',max_length=16,null=True,blank=True)

#配件登记表
class Accessories(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(u'名称', max_length=32, null=False)
    type = models.CharField(u'型号',max_length=16)
    unit = models.CharField(u'单位', max_length=8)
    count = models.SmallIntegerField(u'数量')
    price = models.DecimalField(u'价格',max_digits=9,decimal_places=2)
    status = models.CharField(u'状态',max_length=8)
    register_date = models.DateField(u'日期')
    note = models.CharField(u'备注',max_length=32,null=True,blank=True)

#报废表
class Scrap(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(u'名称',max_length=16, null=False)
    type = models.CharField(u'类型', max_length=16)
    type_number = models.CharField(u'型号', max_length=16)
    unit = models.CharField(u'单位', max_length=8)
    count = models.SmallIntegerField(u'数量')
    l_date = models.DateField(u'日期')
    description = models.CharField(u'报废说明',max_length=32)

#电脑配置统计表
class Statistics(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(u'电脑名',max_length=16)
    main = models.CharField(u'主板', max_length=16,null=True)
    cpu = models.CharField(u'cpu',max_length=16,null=True)
    mem = models.CharField(u'内存',max_length=16,null=True)
    disk = models.CharField(u'硬盘',max_length=16,null=True)
    display = models.CharField(u'显示器',max_length=16,null=True)
    crate = models.CharField(u'机箱',max_length=16,null=True)
    totals = models.SmallIntegerField(u'数量')
