from django.shortcuts import redirect,HttpResponse,render
from django.views.decorators.csrf import csrf_exempt
#分页模块
from project01.pagina.paging import Pagination
#导入rbac组件的models文件
from rbac.models import *
#导入abac组件中的service下面的perssions
from rbac.service.perssions import *
#Modelform 表单模块
from project01.modelforms.froms import *

#注意,如果rbac.models模块在project01项目下面，会覆盖project01的from django.db import models，views页面的就会去找rbac的models模块

import  time

#返回给前端判断用户是否有权限的类,有则为True
class Per(object):
    def __init__(self,actions):
        self.actions=actions
    def add(self):
        return "add" in self.actions
    def delete(self):
        return "delete" in self.actions
    def edit(self):
        return "edit" in self.actions
    def list(self):
        return "search" in self.actions

def index(request):
    return redirect("/login/")

#登陆函数
def login(request):
    if  request.method=="POST":
        user=request.POST.get("user")
        pwd=request.POST.get("pwd")
        #获取Account表里面去找有没有当前的用户名和密码
        user=Account.objects.filter(name=user,pwd=pwd).first()
        if user:
            ############################### 在session中注册用户ID######################
            request.session["user_id"]=user.pk
            #调用组件
            initial_session(user,request)
            return redirect("/device_list/")
    return render(request,"index.html")

#注销
def logout(request):
    del request.session["user_id"]
    return redirect("/index/")

#设备函数
#查询列表
def device_list(request):
    current_page = request.GET.get('page')
    total_count = models.Device.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Device.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()
    #在前端页面显示用户名
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    per = Per(request.actions)

    i=0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Device.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
            return render(request, 'device/device_list.html', locals())
    else:
        return render(request, 'device/device_list.html', locals())

#添加
def add_device(request):
    if  request.method == "POST":
        forms_obj = DeviceForm(request.POST)
        print(forms_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            return redirect("/device_list/")
        else:
            return render(request,"device/add_device.html",locals())
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    forms_obj = DeviceForm()
    return render(request,"device/add_device.html",locals())

#删除
def del_device(request,del_device_id):
    import time
    time.sleep(1.5)
    del_obj = models.Device.objects.get(id=del_device_id)
    del_obj.delete()
    return redirect('/device_list/')

#编辑
def edit_device(request,edit_device_id):
    edit_obj = models.Device.objects.filter(pk=edit_device_id).first()
    if request.method == "POST":
        forms_obj = DeviceForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/device_list/")
        else:
            render(request,"device/edit_device.html",locals())
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    forms_obj = DeviceForm(instance=edit_obj)
    return render(request,"device/edit_device.html",locals())
#设备函数结束

#用户
#查询
def user_list(request):
    current_page = request.GET.get('page')
    total_count = models.User.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.User.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    per = Per(request.actions)

    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.User.objects.filter(name__contains=msg_obj)
        print(filter_obj)
        if filter_obj:
            i +=1
            return render(request, 'user/user_list.html', locals())
    else:
        return render(request, 'user/user_list.html', locals())

#添加
def add_user(request):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    if request.method == "POST":
        name_obj = request.POST.get("name")
        device_id = request.POST.get("device")
        type_obj = request.POST.get("type")
        count_obj = request.POST.get("count")
        start_time_obj = request.POST.get("start_time")
        stop_time_obj = request.POST.get("stop_time")
        note_obj = request.POST.get("note")

        models.User.objects.create(
            name=name_obj,
            type_id=device_id,
            model_number_id=type_obj,
            count=count_obj,
            start_time=start_time_obj,
            stop_time=stop_time_obj,
            note=note_obj
        )
        return redirect('/user_list/')
    dev_obj = models.Device.objects.all()
    return render(request,"user/add_user.html",locals())

#删除
def del_user(request,del_user_id):
    import time
    time.sleep(1.5)
    models.User.objects.get(id=del_user_id).delete()
    return redirect('/user_list/')

#编辑
def edit_user(request,edit_user_id):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    if request.method == "POST":
        user_id = request.POST.get("id")
        name_obj = request.POST.get("name")
        device_obj_id = request.POST.get("device_name")
        type_obj_id = request.POST.get("type_name")
        count_obj = request.POST.get("count")
        start_time_obj = request.POST.get("start_time")
        stop_time_obj = request.POST.get("stop_time")
        note_obj = request.POST.get("note")

        edit_obj = models.User.objects.get(id=user_id)
        edit_obj.name = name_obj
        edit_obj.type_id = device_obj_id
        edit_obj.model_number_id = type_obj_id
        edit_obj.count = count_obj
        edit_obj.start_time = start_time_obj
        edit_obj.stop_time = stop_time_obj
        edit_obj.note = note_obj
        edit_obj.save()
        time.sleep(1.5)
        return redirect('/user_list/')
    else:
        edit_obj = models.User.objects.filter(id=edit_user_id).first()
        device_obj = models.Device.objects.all()
        return render(request, 'user/edit_user.html',locals())
#用户函数结束




#申购函数
#查询
def buy_list(request):
    current_page = request.GET.get('page')
    total_count = models.Buy.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Buy.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    per = Per(request.actions)
    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Buy.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
        return render(request, 'buy/buy_list.html', locals())
    else:
        return render(request, 'buy/buy_list.html',locals())

#添加
def add_buy(requset):
    account_list = Account.objects.all()
    id = requset.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    if  requset.method == "POST":
        forms_obj = BuyForm(requset.POST)
        if forms_obj.is_valid():
            forms_obj.save()
            return redirect("/buy_list/")
        else:
            return render(requset,"buy/add_buy.html",locals())
    forms_obj = BuyForm()
    return render(requset,'buy/add_buy.html',locals())

#删除
def del_buy(request,del_id):
    del_obj = models.Buy.objects.get(id=del_id)
    if del_obj:
        del_obj.delete()
    import time
    time.sleep(1.5)
    return redirect('/buy_list/')

#编辑
def edit_buy(request,edit_buy_id):
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    edit_obj = models.Buy.objects.filter(id=edit_buy_id).first()
    print(edit_obj)
    if request.method == "POST":
        forms_obj = BuyForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/buy_list/")
        else:
            render(request,"buy/edit_buy.html",locals())
    forms_obj = BuyForm(instance=edit_obj)
    return render(request,"buy/edit_buy.html",locals())
#采购结束


#耗材函数
#查询
def cons_list(request):
    current_page = request.GET.get('page')
    total_count = models.Consumable.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Consumable.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    per = Per(request.actions)
    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Consumable.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
        return render(request, 'cons/cons_list.html', locals())
    else:
        return render(request, 'cons/cons_list.html',locals())

#添加
def add_cons(request):
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    if request.method == "POST":
        forms_obj = ConForm(request.POST)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/cons_list/")
        else:
            return render(request,"cons/add_cons.html",locals())
    forms_obj = ConForm()
    return render(request,'cons/add_cons.html',locals())

#删除
def del_cons(request,del_cons_id):
    del_obj = models.Consumable.objects.get(id=del_cons_id)
    if del_obj:
        del_obj.delete()
    import time
    time.sleep(1.5)
    return redirect('/cons_list/')

#编辑
def edit_cons(request,edit_cons_id):
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    edit_obj = models.Consumable.objects.filter(id=edit_cons_id).first()
    if request.method == "POST":
        forms_obj = ConForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/cons_list/")
        else:
            render(request,"cons/edit_cons.html",locals())
    forms_obj = ConForm(instance=edit_obj)
    return render(request,"cons/edit_cons.html",locals())
#耗品函数结束


#电脑配件函数
#列表
def access_list(request):
    current_page = request.GET.get('page')
    total_count = models.Accessories.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Accessories.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()

    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    per = Per(request.actions)
    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Accessories.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
        return render(request, 'access/access_list.html', locals())
    else:
        return render(request, 'access/access_list.html',locals())

#添加
def add_access(request):
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()
    if  request.method == "POST":
        forms_obj = ACCForm(request.POST)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/access_list/")
        else:
            return render(request,"access/add_access.html",locals())
    forms_obj = ACCForm()
    return render(request,'access/add_access.html',locals())

#删除
def del_access(request,del_acc_id):
    del_obj = models.Accessories.objects.get(id=del_acc_id)
    if del_obj:
        del_obj.delete()
    import time
    time.sleep(1.5)
    return redirect('/access_list/')

#编辑
def edit_access(request,edit_acc_id):
    account_list = Account.objects.all()
    id = request.session.get("user_id")
    account = Account.objects.filter(id=id).first()

    edit_obj = models.Accessories.objects.filter(id=edit_acc_id).first()
    if request.method == "POST":
        forms_obj = ACCForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/access_list/")
        else:
            render(request,"access/edit_access.html",locals())
    forms_obj = ACCForm(instance=edit_obj)
    return render(request,"access/edit_access.html",locals())



# 固定资产清理函数
def scrap_list(request):
    current_page = request.GET.get('page')
    total_count = models.Scrap.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Scrap.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()

    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    per = Per(request.actions)

    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Scrap.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
        return render(request, 'scrap/scrap_list.html', locals())
    else:
        return render(request, 'scrap/scrap_list.html',locals())

#添加
def add_scrap(request):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()

    if  request.method == "POST":
        forms_obj = ScrForm(request.POST)
        if forms_obj.is_valid():
            forms_obj.save()
            return redirect("/scrap_list/")
        else:
            return render(request,"scrap/add_scrap.html",locals())
    forms_obj = ScrForm()
    return render(request,'scrap/add_scrap.html',locals())

#删除
def del_scrap(request,del_scrap_id):
    del_scrap_obj = models.Scrap.objects.get(id=del_scrap_id)
    if del_scrap_obj:
        del_scrap_obj.delete()
    import time
    time.sleep(1.5)
    return redirect('/scrap_list/')
#编辑
def edit_scrap(request,edit_scrap_id):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()

    edit_obj = models.Scrap.objects.filter(id=edit_scrap_id).first()
    if request.method == "POST":
        forms_obj = ScrForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/scrap_list/")
        else:
            render(request,"scrap/edit_scrap.html",locals())
    forms_obj = ScrForm(instance=edit_obj)
    return render(request,"scrap/edit_scrap.html",locals())
#固定资产清理函数结束

#电脑配置统计函数
def stat_list(request):
    current_page = request.GET.get('page')
    total_count = models.Statistics.objects.count()
    page_obj = Pagination(current_page, total_count, request.path_info)
    ret = models.Statistics.objects.all()[page_obj.start:page_obj.end]
    page_html = page_obj.page_html()

    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()
    per = Per(request.actions)
    i = 0
    if request.method == "POST":
        msg_obj = request.POST.get("message")
        filter_obj = models.Statistics.objects.filter(name__contains=msg_obj)
        if filter_obj:
            i+=1
        return render(request, 'stat/stat_list.html', locals())
    else:
        return render(request, 'stat/stat_list.html',locals())

def add_stat(request):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()

    if  request.method == "POST":
        forms_obj = StatForm(request.POST)
        if forms_obj.is_valid():
            forms_obj.save()
            return redirect("/stat_list/")
        else:
            return render(request,"stat/add_stat.html",locals())
    forms_obj = StatForm()
    return render(request,'stat/add_stat.html',locals())
    
def del_stat(request,del_stat_id):
    del_stat_obj = models.Statistics.objects.get(id=del_stat_id)
    if del_stat_obj:
        del_stat_obj.delete()
    import time
    time.sleep(1.5)
    return redirect('/stat_list/')

def edit_stat(request,edit_stat_id):
    account_list = Account.objects.all()
    id=request.session.get("user_id")
    account=Account.objects.filter(id=id).first()

    edit_obj = models.Statistics.objects.filter(id=edit_stat_id).first()
    if request.method == "POST":
        forms_obj = StatForm(request.POST, instance=edit_obj)
        if forms_obj.is_valid():
            forms_obj.save()
            time.sleep(1.5)
            return redirect("/stat_list/")
        else:
            render(request,"stat/edit_stat.html",locals())
    forms_obj = StatForm(instance=edit_obj)
    return render(request,"stat/edit_stat.html",locals())
#电脑配置函数结束