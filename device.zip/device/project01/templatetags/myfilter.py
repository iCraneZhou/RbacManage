from django import template
# register = template.Library()
#
# #filter的名字叫open
# @register.filter(name="open")
# def add_open(arg):
#     return "{} sb.".format(arg)
#
# #filter的名字叫stop
# @register.filter(name="stop")
# def add_stop(arg1,arg2):
#     return "{} {}".format(arg1,arg2)