from project01 import models
#导入ModelForm类
from django.forms import ModelForm
#起别名
from django.forms import widgets as wid

#设备表单
class DeviceForm(ModelForm):
    class Meta:
        model=models.Device
        fields="__all__"
        labels={
            "name":"名称",
            "type":"类型",
            "model_number":"型号",
            "count":"数量",
            "status":"状态",
            "register":"日期",
            "note":"备注",
        }
        widgets={
            "name": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入名称..."}),
            "type":wid.TextInput(attrs={"class":"form-control","placeholder":"请输入类型..."}),
            "model_number": wid.TextInput(attrs={"class": "form-control","placeholder":"请输入型号..."}),
            "count": wid.TextInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
            "status": wid.TextInput(attrs={"class": "form-control","placeholder":"请输入状态..."}),
            "register": wid.TextInput(attrs={"class": "form-control","type":"date"}),
            "note": wid.TextInput(attrs={"class": "form-control","placeholder":"请输入备注..."}),
        }
        error_messages={
            "name":{"required": "此处不能为空"},
            "type":{"required":"此处不能为空"},
            "model_number":{"required": "此处不能为空"},
            "count":{"required": "此处不能为空"},
            "status":{"required": "此处不能为空"},
        }

#申购表单
class BuyForm(ModelForm):
    class Meta:
        model=models.Buy
        fields="__all__"
        labels={
            "name":"名称",
            "unit":"单位",
            "count":"数量",
            "price":"价格",
            "reason":"理由",
            "date":"日期",
            "section":"部门",
            "user":"姓名",
            "note":"备注"
        }
        widgets={
            "name":wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入名称..."}),
            "unit":wid.TextInput(attrs={"class":"form-control","placeholder":"请输入单位..."}),
            "count":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
            "price":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入价格..."}),
            "reason":wid.TextInput(attrs={"class": "form-control","placeholder":"请价格申请理由..."}),
            "date":wid.TextInput(attrs={"class": "form-control","type":"date"}),
            "section":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入所在部门..."}),
            "user":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入姓名..."}),
            "note":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入备注..."}),
        }

        error_messages={
            "name":{"required": "此处不能为空"},
            "unit":{"required":"此处不能为空"},
            "count":{"required": "此处不能为空"},
            "price":{"required": "此处不能为空"},
            "reason":{"required": "此处不能为空"},
            "date":{"required": "此处不能为空"},
            "section":{"required": "此处不能为空"},
            "user":{"required": "此处不能为空"},
        }

#耗品领用表单
class ConForm(ModelForm):
    class Meta:
        model=models.Consumable
        fields="__all__"
        labels={
            "name":"名称",
            "unit":"单位",
            "count":"数量",
            "receive":"领用人",
            "section":"部门",
            "receive_date":"领用时间",
            "handle":"经手人",
            "note":"备注"
        }
        widgets={
            "name" :wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入名称..."}),
            "unit" :wid.TextInput(attrs={"class":"form-control","placeholder":"请输入单位..."}),
            "count":wid.NumberInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
            "receive":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入领用人名字..."}),
            "section":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入所在部门..."}),
            "receive_date":wid.TextInput(attrs={"class": "form-control","type":"date"}),
            "handle":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入登记人..."}),
            "note":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入备注..."}),
        }

        error_messages={
            "name" :{"required": "此处不能为空"},
            "unit" :{"required":"此处不能为空"},
            "count":{"required": "此处不能为空"},
            "receive":{"required": "此处不能为空"},
            "section":{"required": "此处不能为空"},
            "receive_date":{"required": "此处不能为空"},
            "handle":{"required": "此处不能为空"},
        }

# 电脑配置表单
class ACCForm(ModelForm):
    class Meta:
        model=models.Accessories
        fields="__all__"
        labels={
            "name":"名称",
            "type":"类型",
            "unit":"单位",
            "count":"数量",
            "price":"价格",
            "status":"状态",
            "register_date":"日期",
            "note":"备注"
        }
        widgets={
            "name" :wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入名称..."}),
            "type": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入类型..."}),
            "unit" :wid.TextInput(attrs={"class":"form-control","placeholder":"请输入单位..."}),
            "count":wid.NumberInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
            "price":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入配件价格..."}),
            "status":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入配置状态..."}),
            "register_date":wid.TextInput(attrs={"class": "form-control","type":"date"}),
            "note":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入备注..."}),
        }

        error_messages={
            "name" :{"required": "此处不能为空"},
            "unit" :{"required":"此处不能为空"},
            "count":{"required": "此处不能为空"},
            "price":{"required": "此处不能为空"},
            "status":{"required": "此处不能为空"},
            "receive_date":{"required": "此处不能为空"},
        }

#固定资产清理表单
class ScrForm(ModelForm):
    class Meta:
        model=models.Scrap
        fields="__all__"
        labels={
            "name":"名称",
            "type":"类型",
            "type_number":"型号",
            "unit":"单位",
            "count":"数量",
            "l_date":"日期",
            "description":"报废说明"
        }
        widgets={
            "name" :wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入名称..."}),
            "type": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入类型..."}),
            "type_number": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入型号..."}),
            "unit" :wid.TextInput(attrs={"class":"form-control","placeholder":"请输入单位..."}),
            "count":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
            "l_date":wid.TextInput(attrs={"class": "form-control","type":"date"}),
            "description":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入报废说明..."}),
        }

        error_messages={
            "name" :{"required": "此处不能为空"},
            "type" :{"required": "此处不能为空"},
            "type_number" :{"required": "此处不能为空"},
            "unit" :{"required":"此处不能为空"},
            "count":{"required": "此处不能为空"},
            "l_date":{"required": "此处不能为空"},
            "description":{"required": "此处不能为空"},
        }

class StatForm(ModelForm):
    class Meta:
        model=models.Statistics
        fields="__all__"
        labels={
            "name":"电脑名称",
            "main":"主板",
            "cpu":"处理器",
            "mem":"内存",
            "disk":"硬盘",
            "display":"显示器",
            "crate":"机箱",
            "totals":"数量",
        }
        widgets={
            "name":wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入电脑名称..."}),
            "main":wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入主板..."}),
            "cpu": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入处理器..."}),
            "mem": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入内存..."}),
            "disk": wid.TextInput(attrs={"class": "form-control", "placeholder": "请输入硬盘..."}),
            "display":wid.TextInput(attrs={"class":"form-control","placeholder":"请输入显示器..."}),
            "crate":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入机箱..."}),
            "totals":wid.TextInput(attrs={"class": "form-control","placeholder":"请输入数量..."}),
        }

        error_messages={
            "name": {"required": "此处不能为空"},
            "main" :{"required": "此处不能为空"},
            "cpu" :{"required": "此处不能为空"},
            "mem" :{"required": "此处不能为空"},
            "disk" :{"required":"此处不能为空"},
            "display":{"required": "此处不能为空"},
            "crate":{"required": "此处不能为空"},
            "totals":{"required": "此处不能为空"},
        }